/*
Dhrumil Patel
TEJ3M
October 2019
First version of menu demo
Shows how to use a menu program
*/

#include <iostream>
#include <conio.h>
#include <string>

using namespace std;

//***********************Wassup*************************
void wassup()
{
	cout << "Yo, wass up!!\n";
	cout << "You can put any program here";
	cin.get();
}

//***********************Intro*************************
void intro()
{
	cout << "Hello World!!!\n\n";
	cout << "This is cool stuff\n";
	cout << "I am a genius programmer\n";
	cout << "Where's my PHD?\n\n\n";
	system("PAUSE");
}

//***********************DevVariables*************************
void DevVariables()
{
	int num;

	cout << "Please enter a number: ";
	cin >> num;
	cin.ignore();
	cout << "You entered: " << num << "\n";
	cin.get();
}

//***********************Strings*************************
void Strings()
{
	string FirstName, LastName;
	system("cls");
	cout << "Enter your first name: ";
	getline(cin, FirstName);
	cout << "Enter your last name: ";
	getline(cin, LastName);
	cout << endl;
	cout << "Hi " << FirstName << " " << LastName << "." << "\n";
	cout << "Welcome to my first C++ string program.\n\n";
	cout << "Sadly, this program has terminated.\n";
	cout << "Goodbye!!";
	cin.get();
}

//***********************bytescalc*************************
void bytescalc()
{
	int size;
	cout << "How many kB is the file? ";
	cin >> size;
	cout << "The file can store " << size*1024 <<" characters";
	cout << "This program has been terminated.";
	//cout << endl;
}

//***********************rect*************************
void rect()
{
	int length, width;
	cout << "Length: ";
	cin >> length;
	cout << "Width: ";
	cin >> width;
	cout << "Perimeter: " << 2 * (length + width);
	cout << "Area: " << length * width;
}

//***********************Egg*************************
void egg()
{
	int eggs;
	cout << "How many eggs in this order?";
	cin >> eggs;
	cout << "This is" << eggs / 12 << "dozens.";
	cout << "Nice doing business with you.";
	cout << "Have a nice day!\n";
	cout << "Take care of those chickens!";
}


//***********************Main Menu*************************
int main()
{ 
int choice;

    do
    {
		system ("cls");
		
    	cout <<"1.Intro " <<"\n\n";
    	
    	cout <<"2.Wassup program "<<"\n\n";	
    	
    	cout <<"3.Strings "<<"\n\n";
    
    	cout <<"4.DevVariables " <<"\n\n";
		
		cout << "5.bytescalc " << "\n\n";

		cout << "6.rect " << "\n\n";

		cout << "7. eggs " << "\n\n";
    
    	cout <<"0.Exit "<<"\n\n";
    	cin >>choice;
		if (choice == 1)
			intro();
		else if (choice == 2)
			wassup();

		else if (choice == 3)
			Strings();

		else if (choice == 4)
			DevVariables();

		else if (choice == 5)
			bytescalc();

		else if (choice == 6)
			rect();

		else if (choice == 7)
			egg();
		
		system("cls");
		cout << endl << endl;
		getch();
		  
    }
    while (choice != 0 );
	cout << endl;
	cout <<"Goodbye!!!";
	getch();
	return (0);
}
